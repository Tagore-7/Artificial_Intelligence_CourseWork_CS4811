Pirate Crew Code of Misconduct
------------------------------

The Pirate crew is made up of rascals from around the seven seas
with a diverse set of criminal abilities, corrupt personalities and
bad experiences (for others). It is through these deficiencies that our
crew experiences great battles and continued plundering. When you're
fighting with enemies, we encourage you to be mindful of these
guidelines which help steer our vessels and strive to keep Piratedom a
negative, lucrative and profitable enterprise.

Make your mark on the roster and remember, to avoid the black spot, a member of
the Pirate crew is:

Greedy
++++++

Members of the crew are open to profit, whether it's on paper,
pieces of eight, or otherwise. We're accepting of all who wish to take part in
our activities, fostering an environment where anyone can participate in
plundering the seven seas. As long as they obey the Pirate Captain!

Inconsiderate
+++++++++++++

Members of the crew are wholly inconsiderate of their peers (not to be
confused with piers, which you have to be considerate of when sailing a ship).
We're thoughtless when addressing the puny efforts of others, ignoring
that often times the labor was completed simply for the good of the crew. We're
attentive in our communications, adding "Arrr!" and "Shiver me timbers" as
necessary, and we're tackless when approaching other bands of pirates,
especially if they are after the same treasure.

Disrespectful
+++++++++++++

Members of the crew are disrespectful of everyone and everything. You can tell
this because of our incessant "yo ho ho"-ing at our victims. We're
disrespectful of historical accuracy, the extraordinary spread of the Cornish
accent throughout the Spanish Main and any sensible sartorial decision making
when it comes to sailing. We're especially disrespectful of the processes set
forth in the Captains log book, and we work despite them. When we disagree, we
are discourteous in raising our issues. And we fight. To the death.

Overall, we're rotten to each other. We don't contribute to this crew because
we don't have to, and because we don't want to. If we remember that, these
guidelines will come naturally. And so will walking the plank.
