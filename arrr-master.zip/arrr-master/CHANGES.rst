Release History
===============

1.0.4
=====

* Cleaned up blots in the cap'n's log.
* More piratical ways to mangle English.

1.0.3
=====

* Project boarded by new pirate matey Calico Hutchison (two new salty phrases).

1.0.2
=====

* Plundered more piratical phrases from t'interwebz.
* A more piratical handling of exceptions.

1.0.1
=====

* More salty seadog parlay vocabulary.

1.0.0
=====

* Minor additions to the vocabulary.
* Black (spot) formatted.

1.0.0.beta.3
============

* Better arrrg parsing contributed by Tony "buccaneer baloney" Shaw.
* Corrections of speeling mistaiks by Esteve "make mine an Aranjuez" Fernandez.

1.0.0.beta.2
============

* Major code optimizations by old salty sea dog Terry Jones.
* A more terrifying logo by Cap'n Steve "Inkspot" Hawkes.
* Addition of a code of mis-conduct (for Pirates) by terror of the seas, Tim
  "No beard" Golden.

1.0.0.beta.1
============

* Minor documentation fixes.
* Minor corrections in the code.

1.0.0.alpha.1
=============

* Initial release.
* Very simple implementation.
* Documentation.
* No tests.
