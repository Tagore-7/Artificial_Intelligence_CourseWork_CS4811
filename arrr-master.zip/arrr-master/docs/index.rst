.. Arrr documentation master file, created by
   sphinx-quickstart on Thu Dec 21 14:41:47 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. include:: ../README.rst

.. include:: ../CONTRIBUTING.rst

API
===

.. automodule:: arrr
    :members:

.. include:: ../CHANGES.rst

License
=======

.. include:: ../LICENSE
